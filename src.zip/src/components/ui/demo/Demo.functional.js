const DemoFunctionalComponent = (props) => {
    return (
        <div className="wrapper">
            <p>This is a para</p>
        </div>
    );
}

export default DemoFunctionalComponent;
